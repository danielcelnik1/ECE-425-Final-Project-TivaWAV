# ECE 425 Final Project Github Repository

## Introduction
This project explores the design and implementation of a digital-to-analog audio output system using pulse-width modulation (PWM) on the Tiva C Series TM4C123 microcontroller. The goal was to read audio data from an SD card reader via serial peripheral interface (SPI) communication protocol and reconstruct an analog waveform capable of driving a speaker through the use of PWM, a low-pass filter, and an amplifier. By leveraging embedded C programming, hardware timer modules, and signal conditioning techniques, this system simulates a basic digital-to-analog converter (DAC) without relying on dedicated audio hardware. The project serves as a hands-on application of digital signal processing concepts in embedded systems, soldering, integrating software, electronics, and real-time control.

## Results and Video Demonstration Link
Regarding challenges faced, the low-pass filter and circuit design was the most time consuming aspect of this project due to the amount of trial-and-error involved with selecting resistor and capacitor values. We opted for a 2-stage low-pass filter to improve audio quality and two DC coupling capacitors to help isolate and bias the PAM8403.

Pressing ‘P’ causes the PLAYING AUDIO… response with the current values on the SD card being read and driven into the PWM system. The SD card system can be observed using a logic analyzer.

Below is a link to a demonstration video of our completed project:
[Video Link](https://youtu.be/y95SkHDTvMQ)

## Background and Methodology
The realization of this project requires background knowledge of embedded systems concepts such as pulse width modulation (PWM) implementation, serial peripheral interface (SPI) and serial synchronous interface (SSI) communication, digital-to-analog conversion (DAC), timer peripheral initialization, low-pass filtering, fixed-point arithmetic and scaling techniques, and general purpose input/output (GPIO) configuration. By implementing all these required techniques, we aim to deepen our understanding of signal processing and strengthen our circuit design and soldering skills for embedded systems applications.

To begin, we load 8-bit PCM data onto an SD card using Linux. We then initialize the SSI module on the Tiva MCU to begin the data transfer from the PMOD SD card reader to the MCU on a sector-by-sector basis. From there, the MCU will load 512 bytes of data from the SD card into a local buffer. This is because the natural sector size of an SD card is 512 bytes, all 512 bytes must be read or the SD card could enter an error state. Since there is only 1 byte of PCM data, we do not need to worry about proper framing and syncing, as long as the sector counter is incrementing properly the audio will be in sync. The data is sized properly for the PWM 2 byte register, and then a Systick delay is utilized to allow the PWM module to drive out the new value for the appropriate sample rate time. 

Once the PCM data has been successfully imported, we initialize the PWM module 1 generator 0 on the MCU and adjust the duty cycle of the PWM wave according to the raw value of the PCM data. We also configured the MCU’s UART0 module to serve as a serial command-line interface, allowing the user to start and stop audio playback via USB communication from a connected PC. Once the PCM data has been encoded, the PWM signal propagates to the low-pass filter. The digital PWM signal is converted into an analog waveform by continuously varying the duty cycle over time; this changing duty cycle, when passed through the low-pass filter, results in a smoothed analog signal. The signal then passes through the class D amplifier, boosting the analog signal’s strength and enabling it to drive the speaker. This all occurs at a sample rate of 44.1 kHz, which is fast enough to accurately reconstruct audio signals up to 22.05 kHz, satisfying the Nyquist criterion for full-range human hearing.

Regarding the low-pass filter’s design, we first started designing with a specific cutoff frequency in mind, however in practice then output had too much noise in the form of clicking. We then opted to add a second stage for a steeper cutoff, which worked perfectly for our application. We used a 100nF capacitor for both stages and used trial-and-error to select the proper resistor values, with 2.7k and 10k respectively offering the best quality.

## Functional Block Diagram
![Block Diagram Image](images/block_diagram.png)

## Table of Components Used
| **Component Name**           | **Subcomponent / Datasheet Link**                                                                                                                                                     | **Quantity** |
|-----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|
| **Low-Pass Filter**         | - 2.7 kΩ Resistor  <br> - 10 kΩ Resistor  <br> - 100 nF Capacitor                                                                                                                       | x1  <br> x1  <br> x2 |
| **Coupling / Bypass Caps**  | - 10 µF Capacitor  <br> - 100 µF Capacitor                                                                                                                                              | x1  <br> x1  |
| **PAM8403 Class D Amp.**    | [Datasheet](https://www.mouser.com/datasheet/2/115/PAM8403-247318.pdf)                                                                                                                 | x1           |
| **4 Ohm 3W Speaker**        | [Product Link](https://www.aliexpress.us/item/3256808081586003.html)                                                                                                                    | x1           |
| **Tiva C TM4C123GH6PM**     |                                                                                                                                                                                         | x1           |
| **PMOD MicroSD Card Slot**  |                                                                                                                                                                                         | x1           |
| **Power Supply (PSU)**      |                                                                                                                                                                                         | x1           |

## Table of Pinout Used
| **Signal**  | **Pin (Port Number)** | **Description**                 |
|-------------|------------------------|---------------------------------|
| SSI2Clk     | PB4 (2)               | SSI module 2 clock              |
| SSI2Fss     | PB5 (2)               | SSI module 2 frame signal       |
| SSI2Rx      | PB6 (2)               | SSI module 2 receive            |
| SSI2Tx      | PB7 (2)               | SSI module 2 transmit           |
| M1PWM0      | PD0 (5)               | Module 1 PWM Generator 0        |
