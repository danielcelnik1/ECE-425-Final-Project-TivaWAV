import wave

INPUT_WAV = "8bit_audio.wav"
OUTPUT_RAW = "output.raw"

S_MARKER = 0x53
SECTOR_SIZE = 512
PADDING_BYTES = 8
USABLE_BYTES = SECTOR_SIZE - 2 * PADDING_BYTES
BYTES_PER_SAMPLE = 2  # 0x53 + 1 byte sample
SAMPLES_PER_SECTOR = USABLE_BYTES // BYTES_PER_SAMPLE

with wave.open(INPUT_WAV, 'rb') as wav, open(OUTPUT_RAW, 'wb') as out:
    assert wav.getsampwidth() == 1, "Expected 8-bit PCM"
    assert wav.getnchannels() == 1, "Expected mono audio"
    assert wav.getframerate() in [8000, 11025, 22050, 32000, 44100], "Unexpected sample rate"

    out.write(bytes([0x00] * PADDING_BYTES))  # Leading padding

    total_samples = 0
    while True:
        frames = wav.readframes(SAMPLES_PER_SECTOR)
        if not frames:
            break

        for byte in frames:
            out.write(bytes([S_MARKER, byte]))
            total_samples += 1

    out.write(bytes([0x00] * PADDING_BYTES))  # Trailing padding

print(f"Wrote {total_samples} samples to {OUTPUT_RAW}")
